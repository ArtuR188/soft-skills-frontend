export const ItemTypes = {
    SLIDER: "slider",
    TEXT_AREA: "textArea",
    RADIO: "radio",
    MULTI_CHOICE: "multiple_choice",
    SKILL_SELECTOR: "skill_selector",  
    YES_NO_QUESTION: "yes_no",
  };