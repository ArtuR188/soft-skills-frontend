import PanelTabs from "../Components/AdminPanel/PanelTabs.js";

export default function AdminPage(){
    return(
        <div>
          <PanelTabs/>
        </div>
    );
}